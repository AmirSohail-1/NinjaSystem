// Fill out your copyright notice in the Description page of Project Settings.


#include "Save/QuestSaveGame.h"


UQuestSaveGame::UQuestSaveGame()
{
}
